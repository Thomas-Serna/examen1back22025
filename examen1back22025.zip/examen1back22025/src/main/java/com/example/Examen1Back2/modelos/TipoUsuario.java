//creacion de nuevo enum para tipos de usuario
package com.example.Examen1Back2.modelos;

public enum TipoUsuario {
    ADMIN,
    DOCENTE,
    ESTUDIANTE
}
