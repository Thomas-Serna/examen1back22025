package com.example.Examen1Back2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Examen1Back2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
